#include "gestionnaireTemporaires.h"



bool estTemporaireUtilise(char* temporaire)
{
    listeChaines* courant = temporairesUtilises;
    while(courant)
    {
        if(strcmp(courant->chaine, temporaire) == 0)
        {
            return true;
        }
        courant = courant->suivant;
    }
    return false;
}

void initialiserTemporaires()
{
    temporairesUtilises = NULL;
    compteurTemporaires = 1;
}


char* creerTemporaire(int type)
{
    char temporaire[10];
    listeChaines* nouv;
    do
    {
        sprintf(temporaire, "temp%d", compteurTemporaires);
        compteurTemporaires++;
    }while(rechercher(temporaire));
    nouv = malloc(sizeof(listeChaines));
    nouv->chaine = strdup(temporaire);
    nouv->type = type;
    nouv->suivant = temporairesUtilises;
    temporairesUtilises = nouv;
    return nouv->chaine;
}

listeChaines* rechercherTemporaire(char* temp)
{
    listeChaines* courant = temporairesUtilises;
    while(courant && strcmp(courant->chaine, temp)!=0)
    {
        courant = courant->suivant;
    }
    return courant;
}
