#ifndef ROUTINES_H_INCLUDED
#define ROUTINES_H_INCLUDED


#include <string.h>
#include "ts.h"
#include "quad.h"
#include "operandes.h"
#include "gestionnaireTemporaires.h"

#define MAX 32500


int bibliotheque;
bool bibliothequesImportees[2];
int typeConstanteCourante;
entite temp;
int type;
int taille;
bool erreur;
int affectationAvecExpression;
extern int yylineno;

void initialiserRoutines();
bool importer(int bibliotheque);
void typeConstante(int type);
bool declarerVariable(char* idf, int type, int taille);
void mettreAJourTypes(int type);
bool declarerConstante(char* idf, int typeIdf, char* valeur);
bool importer(int bibliotheque);
void typeExpression(int type);
bool declarerVariable(char* idf, int type, int taille);
bool typesCompatibles(int typeDestination, int typeSource);
bool verificationChaineIn(char* chaine, char* signe);
bool verificationChaineOut(char* chaine, char* signe);
bool routineLecture(char* chaine);
bool routineEcriture(char* chaine);
int typeDominant(int type1, int type2);
bool routineMultiplication();
bool routineDivision();
bool routineExpressionNiv2(char* operateur);
bool routineExpressionNiv3(char* operateur);
bool expressionNiv4();
bool expressionNiv5();
bool routineExpression();
bool routineAffectation();
bool routineVariableSimple(char* idf);
bool routineVariableSimpleOuConstante(char* idf);
bool routineVariableTableau(char* idf);
bool routineIncrementation();
bool routineDecrementation();
void routineDebutFor();
bool routineSuiteFor();
void routineEnteteFor();
bool routineFor();
bool routineEnteteIf();
bool routineIf();
void test(int i);
bool routineNombrePos(int nb);
bool routineEntierSigne(int entier);

FILE* fichierErreurs;

#endif // ROUTINES_H_INCLUDED
