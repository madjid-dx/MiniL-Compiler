#include "general.h"

void initialiserTout()
{
    yylineno = 1;
    listeEtiquettes = NULL;
    compteurEtiquettes = 0;
    initialiserTS();
    initialiserRoutines();
    initialiserOperandes();
    initialiserQuad();
    erreurSyntax = fopen("erreursyntax.txt","w+");
}


void fin()
{
    fclose(fichierErreurs);
    if(erreur)
    {
        printf("echec de compilation\n");
    }
    else
    {
        ecrireTableDesSymbolesDansFichier();
        ecrireQuadrupletsDansFichier();
        afficherTableDesSymboles();
        afficherPileOperandes();
        afficherListeQuadruplets();
        afficherListeConstantes();
        genererCodeC();
        printf("le programme est correcte \n");
    }
    exit(0);
}

char* nomType(int type)
{
    switch(type)
    {
        case typeINTEGER:
            return strdup("int");
        break;

        case typeREAL:
            return strdup("float");
        break;

        case typeSTR:
            return strdup("char*");
        break;

        case typeBOOLEAN:
            return strdup("int");
        break;
    }
    return "";
}


int typeSymboleOuTemp(char* var)
{
    entite* e = rechercher(var);
    if(e)
    {
        return e->type;
    }
    listeChaines* temp = rechercherTemporaire(var);
    return temp->type;
}

char* formeCQuadruplet(quadruplet* quad)
{
    char resultat[100];
    etiquette* etiq;
    if(quad)
    {
        if(strcmp(quad->operateur, "Out") == 0)
        {
            sprintf(resultat, "printf(%s, %s)", quad->operande1, quad->operande2);
        }
        else if(strcmp(quad->operateur, "In") == 0)
        {
            switch(typeSymboleOuTemp(quad->resultat))
            {
                case typeSTR:
                    sprintf(resultat, "scanf(%s, %s)", quad->operande1, quad->resultat);
                break;

                default:
                    sprintf(resultat, "scanf(%s, &%s)", quad->operande1, quad->resultat);
                break;
            }
        }
        else if(strcmp(quad->operateur, "BR") == 0)
        {
            etiq = recupererEtiquette(atoi(quad->operande1));
            sprintf(resultat, "goto %s", etiq->nom);
        }
        else if(strcmp(quad->operateur, "BNZ") == 0)
        {
            etiq = recupererEtiquette(atoi(quad->operande1));
            sprintf(resultat, "if(%s) goto %s", quad->operande2, etiq->nom);
        }
        else if(strcmp(quad->operateur, "BZ") == 0)
        {
            etiq = recupererEtiquette(atoi(quad->operande1));
            sprintf(resultat, "if(!%s) goto %s", quad->operande2, etiq->nom);
        }
        else if(strcmp(quad->operateur, ":=") == 0)
        {
            sprintf(resultat, "%s = %s", quad->resultat, quad->operande1);
        }
        else
        {
            if(strcmp(quad->operateur, "BOUNDS") != 0 && strcmp(quad->operateur, "ADEC") != 0)
            {
                sprintf(resultat, "%s = %s %s %s", quad->resultat, quad->operande1, quad->operateur, quad->operande2);
            }
            else
            {
                sprintf(resultat, "");
            }
        }
        return strdup(resultat);

    }
    return "";
}


void genererCodeC()
{
    FILE* fichier= fopen("codeC.c", "w+");
    listeEntite* courantTS = tableDesSymboles;
    listeChaines* courantTemp = temporairesUtilises;
    quadruplet* courantQuad = teteQuadruplets;
    int positionQuadrupletCourant = 1;
    etiquette* etiq;
    genererListeEtiquettes();
    char* tempFormeCQuad;
    if(fichier)
    {
        if(bibliothequesImportees[lang])
        {
            fprintf(fichier, "#include <stdlib.h>\n");
        }
        if(bibliothequesImportees[io])
        {
            fprintf(fichier, "#include <stdio.h>\n");
        }

        fprintf(fichier, "int main()\n{\n");
        for(;courantTS; courantTS=courantTS->suivant)
        {
            if(courantTS->e.nat == natureCONST)
            {
                fprintf(fichier, "\tconst %s %s = %s;\n", nomType(courantTS->e.type), courantTS->e.nom, rechercherConstante(courantTS->e.nom)->valeur);
            }
            else
            {
                if(courantTS->e.taille > 0)
                {
                    fprintf(fichier, "\t%s %s[%d];\n", nomType(courantTS->e.type), courantTS->e.nom, courantTS->e.taille);
                }
                else
                {
                    fprintf(fichier, "\t%s %s;\n", nomType(courantTS->e.type), courantTS->e.nom);
                }
            }
        }
        for(;courantTemp; courantTemp = courantTemp->suivant)
        {
            fprintf(fichier, "\t%s %s;\n", nomType(courantTemp->type), courantTemp->chaine);
        }
        for(;courantQuad; courantQuad = courantQuad->suivant)
        {
            etiq = recupererEtiquette(positionQuadrupletCourant);
            if(etiq)
            {
                fprintf(fichier, "\t%s: ", etiq->nom);
            }
            positionQuadrupletCourant++;
            tempFormeCQuad = formeCQuadruplet(courantQuad);
            if(strcmp(tempFormeCQuad, "") != 0)
            {
                fprintf(fichier, "\t%s;\n", tempFormeCQuad);
            }
        }
        etiq = recupererEtiquette(positionQuadrupletCourant);
        if(etiq)
        {
            fprintf(fichier, "\t%s : ", etiq->nom);
        }
        else
        {
            printf("pas d'etiquette avec la ligne %d", positionQuadrupletCourant);
        }
        fprintf(fichier, "return 0;\n}");
        afficherListeEtiquettes();
        fclose(fichier);
    }
}


void genererListeEtiquettes()
{
    quadruplet* quadCourant = teteQuadruplets;
    int numQuad;
    etiquette* tempEtiquette;
    while(quadCourant)
    {
        if(strcmp(quadCourant->operateur, "BR") == 0 || strcmp(quadCourant->operateur, "BNZ")==0 || strcmp(quadCourant->operateur, "BZ")==0)
        {
            numQuad = atoi(quadCourant->operande1);
            tempEtiquette = recupererEtiquette(numQuad);
            if(!tempEtiquette)
            {
                ajouterEtiquette(numQuad);
            }
        }
        quadCourant = quadCourant->suivant;
    }
}

void ajouterEtiquette(int numeroQuadruplet)
{
    char temp[10];
    etiquette* nouv=NULL;
    do
    {
            sprintf(temp, "etiq%d", compteurEtiquettes);
            compteurEtiquettes++;
    }while(rechercher(temp) || rechercherTemporaire(temp));
    nouv = malloc(sizeof(etiquette));
    nouv->nom = strdup(temp);
    nouv->numeroQuadruplet = numeroQuadruplet;
    nouv->suivant = listeEtiquettes;
    listeEtiquettes = nouv;
}

etiquette* recupererEtiquette(int numeroQuadruplet)
{
    etiquette* courante = listeEtiquettes;
    while(courante && courante->numeroQuadruplet != numeroQuadruplet)
    {
        courante = courante->suivant;
    }
    return courante;
}

void afficherListeEtiquettes()
{
    printf("------------------liste des etiquettes------------------\n");
    etiquette* courante = listeEtiquettes;
    while(courante)
    {
        printf("%s\t%d\n", courante->nom, courante->numeroQuadruplet);
        courante = courante->suivant;
    }
    printf("--------------------------------------------------------\n");
}

