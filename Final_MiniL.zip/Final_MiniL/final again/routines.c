#include "routines.h"

bool importer(int bibliotheque)
{
    if(bibliotheque != io && bibliotheque != lang)
    {
        return false;
    }
    if(bibliothequesImportees[bibliotheque])
    {
        printf("warning pres de la ligne %d: importation double\n", yylineno);
        return false;
    }
    bibliothequesImportees[bibliotheque] = true;
    return true;
}

void typeConstante(int type)
{
    typeConstanteCourante = type;
}


bool declarerVariable(char* idf, int type, int taille)
{
    if(rechercher(idf))
    {
        return false;
    }
    else
    {
        inserer(idf, natureVAR, type, taille);
        if(taille > 0)
        {
            char temp[10];
            sprintf(temp, "%d", taille);
            insererQuadruplet(creerQuadruplet("BOUNDS", temp, temp, ""));
            insererQuadruplet(creerQuadruplet("ADEC", idf, "", ""));
        }
        return true;
    }
}

bool declarerConstante(char* idf, int typeIdf, char* valeur)
{
    if(rechercher(idf))
    {
        printf("erreur pres de la ligne %d: redeclaration de %s\n",yylineno, idf);
        fprintf(fichierErreurs, "erreur pres de la ligne %d: redeclaration de %s\n",yylineno, idf);
        erreur = true;
        return false;
    }
    if(typeIdf != typeConstanteCourante)
    {
        printf("erreur pres de la ligne %d: incompatibilité de types\n", yylineno);
        printf(fichierErreurs, "erreur pres de la ligne %d: incompatibilité de types\n", yylineno);
        erreur = true;
        return false;
    }
    inserer(idf, natureCONST, typeIdf, 0);
    insererConstante(idf, valeur);
    return true;
}


bool verificationChaineIn(char* chaine, char* signe)
{
    if(strlen(chaine) != 4)
    {
        return false;
    }
    if(chaine[1] != '%')
    {
        return false;
    }
    if(chaine[2] != 's' && chaine[2] != 'd' && chaine[2] != 'f')
    {
        return false;
    }
    *signe = chaine[2];
    return true;
}

int typeSigneFormatage(char signe)
{
    if(signe == 's')
    {
        return typeSTR;
    }
    if(signe == 'd')
    {
        return typeINTEGER;
    }
    if(signe == 'f')
    {
        return typeREAL;
    }
    return -1;
}

bool routineLecture(char* chaine)
{
    bool resultat= true;
    char signe;
    operande* op = depilerOperande();
    creerEtInsererQuadruplet("In", chaine, "", op->nomOuValeur);
    if(!bibliothequesImportees[io])
    {
        printf("erreur pres de la ligne %d: Import MiniL.lang requit pour une Lecture\n", yylineno);
        fprintf(fichierErreurs,"erreur pres de la ligne %d: Import MiniL.lang requit pour une Lecture\n", yylineno);
        erreur = true;
        resultat = false;
    }
    if(!verificationChaineIn(chaine, &signe))
    {
        printf("erreur pres de la ligne %d: signe de formatage seule requis\n", yylineno);
        fprintf(fichierErreurs ,"erreur pres de la ligne %d: signe de formatage seule requis\n", yylineno);
        erreur = true;
        resultat = false;
    }
    else
    {
        if(typeSigneFormatage(signe) != op->type && op->type != typeTemporaire)
        {
            printf("erreur pres de la ligne %d: signe de formatage '%c' incompatible avec le type de '%s'\n",yylineno, signe, op->nomOuValeur);
            fprintf(fichierErreurs ,"erreur pres de la ligne %d: signe de formatage '%c' incompatible avec le type de '%s'\n",yylineno, signe, op->nomOuValeur);
            erreur = true;
            resultat = false;
        }
    }
    return resultat;
}

bool verificationChaineOut(char* chaine, char* signe)
{
    int i;
    int n = strlen(chaine);
    bool trouve = false;
    for(i=0; i<n-1; i++)
    {
        if(chaine[i] == '%' && (i==0 || chaine[i-1] != '\\'))
        {
            if(chaine[i+1] == 's' || chaine[i+1] == 'd' || chaine[i+1] == 'f')
            {
                if(!trouve)
                {
                    trouve = true;
                    *signe = chaine[i+1];
                }
                else
                {
                    trouve = false;
                    break;
                }
            }
        }
    }
    return trouve;
}

bool routineEcriture(char* chaine)
{
    char signe;
    operande* op = depilerOperande();
    creerEtInsererQuadruplet("Out", chaine, op->nomOuValeur, "");
    bool resultat = true;
    if(!bibliothequesImportees[io])
    {
        printf("erreur pres de la ligne %d: Import MiniL.lang requit pour une Ecriture\n", yylineno);
        fprintf(fichierErreurs, "erreur pres de la ligne %d: Import MiniL.lang requit pour une Ecriture\n", yylineno);
        erreur = true;
        resultat = false;
    }
    if(!verificationChaineOut(chaine, &signe))
    {
        printf("erreur pres de la ligne %d: la chaine '%s' ne contient pas un seul signe de formatage\n",yylineno, chaine);
        fprintf(fichierErreurs ,"erreur pres de la ligne %d: la chaine '%s' ne contient pas un seul signe de formatage\n",yylineno, chaine);
        erreur = true;
        resultat = false;
    }
    else
    {
        if(typeSigneFormatage(signe) != op->type && op->type != typeTemporaire)
        {
            printf("erreur pres de la ligne %d: signe de formatage '%c' incompatible avec le type de '%s'\n",yylineno, signe, op->nomOuValeur);
            fprintf(fichierErreurs,"erreur pres de la ligne %d: signe de formatage '%c' incompatible avec le type de '%s'\n",yylineno, signe, op->nomOuValeur);
            erreur = true;
            resultat = false;
        }
    }
    return resultat;
}


void initialiserRoutines()
{
    bibliothequesImportees[0] = false;
    bibliothequesImportees[1] = false;
    taille=0;
    erreur = false;
    affectationAvecExpression = false;
    fichierErreurs = fopen("erreurs.txt", "w+");
}


bool routineMultiplication()
{
    operande* op2 = depilerOperande();
    operande* op1 = depilerOperande();
    char* temporaire = creerTemporaire(op1->type);
    creerEtEmpilerOperande(temporaire, op1->type);
    creerEtInsererQuadruplet("*", op1->nomOuValeur, op2->nomOuValeur, temporaire);
    if(op2->type != op1->type && op2->type != typeTemporaire && op1->type != typeTemporaire)
    {
        printf("erreur pres de la ligne %d: types incompatibles pour l'operateur * \n", yylineno);
        fprintf(fichierErreurs, "erreur pres de la ligne %d: types incompatibles pour l'operateur * \n", yylineno);
        erreur = true;
        return false;
    }
    return true;
}

bool routineDivision()
{
    operande* op2 = depilerOperande();
    operande* op1 = depilerOperande();
    char* temporaire = creerTemporaire(typeREAL);
    creerEtEmpilerOperande(temporaire, typeREAL);
    creerEtInsererQuadruplet("/", op1->nomOuValeur, op2->nomOuValeur, temporaire);
    if(op2->type != op1->type && op2->type != typeTemporaire && op1->type != typeTemporaire)
    {
        printf("erreur pres de la ligne %d: types incompatibles pour l'operateur /\n", yylineno);
        fprintf(fichierErreurs, "erreur pres de la ligne %d: types incompatibles pour l'operateur /\n", yylineno);
        erreur = true;
        return false;
    }
    return true;
}

bool routineExpressionNiv2(char* operateur)
{
    operande* op2 = depilerOperande();
    operande* op1 = depilerOperande();
    char* temporaire = creerTemporaire(op1->type);
    creerEtEmpilerOperande(temporaire, (op1->type == op2->type) ? op1->type : typeTemporaire);
    creerEtInsererQuadruplet(strdup(operateur), op1->nomOuValeur, op2->nomOuValeur, temporaire);
    if(op1->type != op2->type && op1->type != typeTemporaire && op2->type != typeTemporaire)
    {
        printf("erreur pres de la ligne %d: types incompatibles pour l'operateur %s\n", yylineno, operateur);
        fprintf(fichierErreurs,"erreur pres de la ligne %d: types incompatibles pour l'operateur %s\n", yylineno, operateur);
        erreur = true;
        return false;
    }
    return true;
}


bool routineExpressionNiv3(char* operateur)
{
    operande* op2 = depilerOperande();
    operande* op1 = depilerOperande();
    char* temporaire = creerTemporaire(typeBOOLEAN);
    creerEtEmpilerOperande(temporaire, typeBOOLEAN);
    creerEtInsererQuadruplet(strdup(operateur), op1->nomOuValeur, op2->nomOuValeur, temporaire);
    if(op1->type != op2->type && op1->type != typeTemporaire && op2->type != typeTemporaire)
    {
        printf("erreur pres de la ligne %d: types incompatibles pour l'operateur %s\n",yylineno, operateur);
        fprintf(fichierErreurs, "erreur pres de la ligne %d: types incompatibles pour l'operateur %s\n",yylineno, operateur);
        erreur = true;
        return false;
    }
    return true;
}

bool expressionNiv4()
{
    operande* op = depilerOperande();
    char* temporaire = creerTemporaire(typeBOOLEAN);
    creerEtEmpilerOperande(temporaire, typeBOOLEAN);
    creerEtInsererQuadruplet("!", "", op->nomOuValeur, temporaire);
    if(op->type != typeBOOLEAN)
    {
        printf("erreur pres de la ligne %d: types incompatibles pour l'operateur !", yylineno);
        fprintf(fichierErreurs ,"erreur pres de la ligne %d: types incompatibles pour l'operateur !", yylineno);
        erreur = true;
        return false;
    }
    return true;
}

bool expressionNiv5()
{
    operande* op2 = depilerOperande();
    operande* op1 = depilerOperande();
    char* temporaire = creerTemporaire(typeBOOLEAN);
    creerEtEmpilerOperande(temporaire, typeBOOLEAN);
    creerEtInsererQuadruplet("&", op1->nomOuValeur, op2->nomOuValeur, temporaire);
    if(op1->type != typeBOOLEAN || op2->type != typeBOOLEAN)
    {
        printf("erreur pres de la ligne %d: types incompatibles pour l'operateur &\n", yylineno);
        fprintf(fichierErreurs, "erreur pres de la ligne %d: types incompatibles pour l'operateur &\n", yylineno);
        erreur = true;
        return false;
    }
    return true;
}

bool routineExpression()
{
    operande* op2 = depilerOperande();
    operande* op1 = depilerOperande();
    char* temporaire = creerTemporaire(typeBOOLEAN);
    creerEtEmpilerOperande(temporaire, typeBOOLEAN);
    creerEtInsererQuadruplet("|", op1->nomOuValeur, op2->nomOuValeur, temporaire);
    if(op1->type != typeBOOLEAN || op2->type != typeBOOLEAN)
    {
        printf("erreur pres de la ligne %d: types incompatibles pour l'operateur |\n", yylineno);
        fprintf(fichierErreurs, "erreur pres de la ligne %d: types incompatibles pour l'operateur |\n", yylineno);
        erreur = true;
        return false;
    }
    return true;
}


void mettreAJourTypes(int type)
{
    listeEntite* courant = tableDesSymboles;
    while(courant)
    {
        if(courant->e.type == typeTemporaire)
        {
            courant->e.type = type;
        }
        courant = courant->suivant;
    }
}

bool typesCompatibles(int type1, int type2)
{
    return (type1 == type2);
}

bool routineAffectation()
{
    operande* source = depilerOperande();
    operande* destination = depilerOperande();
    creerEtInsererQuadruplet(":=", source->nomOuValeur, "", destination->nomOuValeur);
    if(destination->type != source->type && destination->type != typeTemporaire && source->type != typeTemporaire)
    {
        printf("erreur pres de la ligne %d: types source different du type destination\n", yylineno);
        fprintf(fichierErreurs, "erreur pres de la ligne %d: types source different du type destination\n", yylineno);
        erreur = true;
        return false;
    }
    if(!bibliothequesImportees[lang])
    {
        printf("erreur pres de la ligne %d: Import MiniL.lang requit pour une affectation\n", yylineno);
        printf(fichierErreurs, "erreur pres de la ligne %d: Import MiniL.lang requit pour une affectation\n", yylineno);
        erreur = true;
        return false;
    }
    return true;
}

bool routineVariableSimpleOuConstante(char* idf)
{
    entite* entiteIDF = rechercher(idf);
    if(entiteIDF)
    {
        creerEtEmpilerOperande(entiteIDF->nom, entiteIDF->type);
        return true;
    }
    else
    {
        creerEtEmpilerOperande(idf, typeTemporaire);
        printf("erreur pres de la ligne %d: %s non declare\n",yylineno, idf);
        fprintf(fichierErreurs, "erreur pres de la ligne %d: %s non declare\n",yylineno, idf);
        erreur = true;
        return false;
    }

}

bool routineVariableSimple(char* idf)
{
    entite* entiteIDF = rechercher(idf);
    if(entiteIDF)
    {
        creerEtEmpilerOperande(entiteIDF->nom, entiteIDF->type);
        if(entiteIDF->nat == natureCONST)
        {
            printf("erreur pres de la ligne %d: on ne peut pas affecter à une constante\n", yylineno);
            fprintf(fichierErreurs, "erreur pres de la ligne %d: on ne peut pas affecter à une constante\n", yylineno);
            erreur = true;
            return false;
        }
        return true;
    }
    else
    {
        creerEtEmpilerOperande(idf, typeTemporaire);
        printf("erreur pres de la ligne %d: %s non declare\n", yylineno, idf);
        fprintf(fichierErreurs, "erreur pres de la ligne %d: %s non declare\n", yylineno, idf);
        erreur = true;
        return false;
    }
}


bool routineVariableTableau(char* idf)
{
    entite* entiteIDF = rechercher(idf);
    operande* indice = depilerOperande();
    char temp[100];
    if(entiteIDF)
    {
        sprintf(temp, "%s[%s]", entiteIDF->nom, indice->nomOuValeur);
        creerEtEmpilerOperande(temp, entiteIDF->type);
        if(indice->type != typeINTEGER && indice->type != typeTemporaire)
        {
            printf("erreur pres de la ligne %d: la reference d'un element d'un tableau doit etre de type entier\n", yylineno);
            fprintf(fichierErreurs, "erreur pres de la ligne %d: la reference d'un element d'un tableau doit etre de type entier\n", yylineno);
            erreur = true;
            return false;
        }
        return true;
    }
    else
    {
        creerEtEmpilerOperande(idf, typeTemporaire);
        printf("erreur pres de la ligne %d: %s non declare\n",yylineno, idf);
        fprintf(fichierErreurs, "erreur pres de la ligne %d: %s non declare\n",yylineno, idf);
        erreur = true;
    }
    return true;
}

bool routineIncrementation()
{
    operande* op = depilerOperande();
    char* temporaire = creerTemporaire(op->type);
    if(op->type == typeINTEGER)
    {
        creerEtInsererQuadruplet("+", op->nomOuValeur, "1", temporaire);
    }
    else
    {
        creerEtInsererQuadruplet("+", op->nomOuValeur, "1.0", temporaire);
    }
    creerEtInsererQuadruplet(":=", temporaire, "", op->nomOuValeur);
    if(op->type == typeSTR && op->type != typeTemporaire)
    {
        printf("erreur pres de la ligne %d: une chaine de caractère ne peut etre incrementée\n", yylineno);
        fprintf(fichierErreurs, "erreur pres de la ligne %d: une chaine de caractère ne peut etre incrementée\n", yylineno);
        erreur = true;
        return false;
    }
    return true;
}


bool routineDecrementation()
{
    operande* op = depilerOperande();
    char* temporaire = creerTemporaire(op->type);
    if(op->type == typeINTEGER)
    {
        creerEtInsererQuadruplet("-", op->nomOuValeur, "1", temporaire);
    }
    else
    {
        creerEtInsererQuadruplet("-", op->nomOuValeur, "1.0", temporaire);
    }
    creerEtInsererQuadruplet(":=", temporaire, "", op->nomOuValeur);
    if(op->type == typeSTR && op->type != typeTemporaire)
    {
        printf("erreur pres de la ligne %d: une chaine de caractère ne peut etre incrementée\n", yylineno);
        fprintf(fichierErreurs, "erreur pres de la ligne %d: une chaine de caractère ne peut etre incrementée\n", yylineno);
        erreur = true;
        return false;
    }
    return true;
}


void routineDebutFor()
{
    empilerFor();
    pileFor->positionCondition = tailleListeQuadruplets() + 1 ;
}

bool routineSuiteFor()
{
    operande* op = depilerOperande();
    creerEtInsererQuadruplet("BNZ", "", op->nomOuValeur, "");
    pileFor->positionBNZ = tailleListeQuadruplets();
    creerEtInsererQuadruplet("BR", "", "", "");
    if(op->type != typeBOOLEAN)
    {
        printf("erreur pres de la ligne %d: expression booleene requise\n", yylineno);
        fprintf(fichierErreurs ,"erreur pres de la ligne %d: expression booleene requise\n", yylineno);
        erreur = true;
        return false;
    }
    return true;
}

void routineEnteteFor()
{
    char temp[10];
    char temp2[10];
    sprintf(temp, "%d", pileFor->positionCondition);
    creerEtInsererQuadruplet("BR", temp, "", "");
    quadruplet* BNZ = recupererQuadruplet(pileFor->positionBNZ);
    sprintf(temp2, "%d", tailleListeQuadruplets()+1);
    BNZ->operande1 = strdup(temp2);
}


bool routineFor()
{
    char temp[10];
    char temp2[10];
    sprintf(temp, "%d", pileFor->positionBNZ+2);
    creerEtInsererQuadruplet("BR", strdup(temp), "", "");
    quadruplet* BRFin = recupererQuadruplet(pileFor->positionBNZ +1);
    sprintf(temp2, "%d", tailleListeQuadruplets()+1);
    BRFin->operande1 = strdup(temp2);
    depilerFor();
    if(!bibliothequesImportees[lang])
    {
        printf("erreur pres de la ligne %d: Import MiniL.lang requit pour une boucle For\n", yylineno);
        fprintf(fichierErreurs,"erreur pres de la ligne %d: Import MiniL.lang requit pour une boucle For\n", yylineno);
        erreur = true;
        return false;
    }
    return true;
}


bool routineIf()
{
    char temp[10];
    quadruplet* BZFin = recupererQuadruplet(pileIf->positionBZ);
    sprintf(temp, "%d", tailleListeQuadruplets()+1);
    BZFin->operande1 = strdup(temp);
    depilerIf();
    if(!bibliothequesImportees[lang])
    {
        printf("erreur pres de la ligne %d: Import MiniL.lang requit pour une instruction If\n", yylineno);
        fprintf(fichierErreurs,"erreur pres de la ligne %d: Import MiniL.lang requit pour une instruction If\n", yylineno);
        erreur = true;
        return false;
    }
    return true;
}


bool routineEnteteIf()
{
    empilerIf();
    operande* op = depilerOperande();
    creerEtInsererQuadruplet("BZ", "", op->nomOuValeur, "");
    pileIf->positionBZ = tailleListeQuadruplets();
    if(op->type != typeBOOLEAN)
    {
        printf("erreur pres de la ligne %d: expression booleene requise\n", yylineno);
        fprintf(fichierErreurs ,"erreur pres de la ligne %d: expression booleene requise\n", yylineno);
        erreur = true;
        return false;
    }
    return true;
}

bool routineNombrePos(int nb)
{
    if(nb > MAX)
    {
        printf("erreur pres de la ligne %d: taille max pour les nombres positifs depassée\n", yylineno);
        fprintf(fichierErreurs ,"erreur pres de la ligne %d: taille max pour les nombres positifs depassée\n", yylineno);
        erreur = true;
        return false;
    }
    return true;
}


bool routineEntierSigne(int entier)
{
    if(entier > MAX || entier < -MAX)
    {
        printf("erreur pres de la ligne %d: valeur absolue max pour les nombres positifs depassée\n", yylineno);
        fprintf(fichierErreurs ,"erreur pres de la ligne %d: valeur absolue max pour les nombres positifs depassée\n", yylineno);
        erreur = true;
        return false;
    }
    return true;
}
