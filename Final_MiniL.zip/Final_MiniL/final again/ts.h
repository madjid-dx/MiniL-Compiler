#ifndef TS
#define TS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define true 1
#define false 0

#define typeBOOLEAN 0
#define typeINTEGER 1
#define typeREAL 2
#define typeSTR 3
#define typeTemporaire -1
#define natureVAR 0
#define natureCONST 1
#define natureMOTCLE 2
#define lang 0
#define io 1


typedef struct entite entite;
typedef struct listeEntite listeEntite;
typedef int bool;
typedef struct listeConstantes listeConstantes;

entite creerEntite(char* nom, int nat, int type, int taille);
bool copierEntite(entite* source, entite* destination);
void inserer(char* nom, int nat, int type, int taille);
void afficherEntite(entite* e);
entite* rechercher(char* nom);
void afficherTableDesSymboles();
void initialiserTS();
void ecrireTableDesSymbolesDansFichier();
listeConstantes* rechercherConstante(char* nom);
void afficherListeConstantes();
void afficherElementListeConstante(listeConstantes* element);
void insererConstante(char* nom, char* valeur);

struct entite
{
    char nom[100];
    int nat;
    int type;
    int taille;
};

struct listeEntite
{
    entite e;
    listeEntite* suivant;
};

struct listeConstantes
{
    char* nom;
    char* valeur;
    listeConstantes* suivant;
};



listeEntite* tableDesSymboles;
listeConstantes* teteListeConstantes;

#endif
