#include "operandes.h"


operande* creerOperande(char* nomOuValeur, int type)
{
    operande* op = malloc(sizeof(operande));
    op->nomOuValeur = strdup(nomOuValeur);
    op->type = type;
    op->suivant = NULL;
    return op;
}

void empilerOperande(operande* op)
{
    if(op)
    {
        op->suivant = pileOperandes;
        pileOperandes = op;
    }
}

void creerEtEmpilerOperande(char* nom, int type)
{
    empilerOperande(creerOperande(nom, type));
}

operande* depilerOperande()
{
    operande* resultat;
    if(pileOperandes)
    {
        resultat = pileOperandes;
        pileOperandes = pileOperandes->suivant;
        return resultat;
    }
    return NULL;
}

void initialiserOperandes()
{
    pileOperandes = NULL;
    pileFor = NULL;
    pileIf = NULL;
}


void afficherOperande(operande* op)
{
    if(op)
    {
        printf("%s\t", op->nomOuValeur);
        printf("%d\t", op->type);
    }
}


void afficherPileOperandes()
{
    operande* courant = pileOperandes;
    printf("-------------Pile des operandes--------------\n");
    while(courant)
    {
        afficherOperande(courant);
        printf("\n");
        courant = courant->suivant;
    }
    printf("---------------------------\n");
}

void empilerFor()
{
    descripteurFor* nouv = malloc(sizeof(descripteurFor));
    nouv->suivant = pileFor;
    pileFor = nouv;
}

void depilerFor()
{
    pileFor = pileFor->suivant;
}


void empilerIf()
{
    descripteurIf* nouv = malloc(sizeof(descripteurIf));
    nouv->suivant = pileIf;
    pileIf = nouv;
}

void depilerIf()
{
    pileIf = pileIf->suivant;
}

