#include "ts.h"

entite creerEntite(char* nom, int nat, int type, int taille)
{
    entite e;
    strcpy(e.nom, nom);
    e.nat = nat;
    e.type = type;
    e.taille = taille;
    return e;
}

bool copierEntite(entite* source, entite* destination)
{
    if(!source || !destination)
    {
        return false;
    }
    destination->nat = source->nat;
    destination->taille = source->taille;
    destination->type = source->type;
    strcpy(destination->nom, source->nom);
    return true;
}


void inserer(char* nom, int nat, int type, int taille)
{
    listeEntite* nouveau = malloc(sizeof(listeEntite));
    nouveau->suivant = tableDesSymboles;
    nouveau->e = creerEntite(nom, nat, type, taille);
    tableDesSymboles = nouveau;
}

void afficherEntite(entite* e)
{
    printf("nom = %s | type = %d | nat = %d | taille = %d \n", e->nom, e->type, e->nat, e->taille);
}


void afficherTableDesSymboles()
{
    listeEntite* courant = tableDesSymboles;
    while(courant)
    {
        afficherEntite(&(courant->e));
        courant = courant->suivant;
    }
}

entite* rechercher(char* nom)
{
    listeEntite* courant = tableDesSymboles;
	while(courant)
	{
		if(strcmp(courant->e.nom, nom) == 0)
		{
			return &(courant->e);
		}
		courant = courant->suivant;
	}
	return NULL;
}

void initialiserTS()
{
    tableDesSymboles = NULL;
    teteListeConstantes = NULL;
}

void ecrireTableDesSymbolesDansFichier()
{
	FILE *f=fopen("ts.txt","w+");
	listeEntite *p=tableDesSymboles;
	if(f)
	{
        while(p!=NULL)
        {
            fprintf(f,"%s\t%d\t%d\t%d\n",p->e.nom,p->e.type,p->e.nat,p->e.taille);
            p=p->suivant;
        }
        fclose(f);
	}
    else
    {
        printf("erreur de creation de ts.txt\n");
    }
}

void insererConstante(char* nom, char* valeur)
{
    listeConstantes* nouveau = malloc(sizeof(listeConstantes));
    nouveau->suivant = teteListeConstantes;
    nouveau->nom = strdup(nom);
    nouveau->valeur = strdup(valeur);
    teteListeConstantes = nouveau;
}

void afficherElementListeConstante(listeConstantes* element)
{
    printf("nom = %s | valeur = %s ", element->nom, element->valeur);
}


void afficherListeConstantes()
{
    listeConstantes* courant = teteListeConstantes;
    while(courant)
    {
        afficherElementListeConstante(courant);
        printf("\n");
        courant = courant->suivant;
    }
}

listeConstantes* rechercherConstante(char* nom)
{
    listeConstantes* courant = teteListeConstantes;
	while(courant)
	{
		if(strcmp(courant->nom, nom) == 0)
		{
			return courant;
		}
		courant = courant->suivant;
	}
	return NULL;
}


void ecrireListeConstantesDansFichier()
{
	FILE *f=fopen("listeConstantes.txt","w+");
	listeConstantes *p=teteListeConstantes;
	if(f)
	{
        while(p!=NULL)
        {
            fprintf(f,"%s\t%s\n",p->nom,p->valeur);
            p=p->suivant;
        }
        fclose(f);
	}
    else
    {
        printf("erreur de creation de listeConstantes.txt\n");
    }
}
