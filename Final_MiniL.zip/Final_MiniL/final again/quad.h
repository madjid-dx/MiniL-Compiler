#ifndef QUAD_H_INCLUDED
#define QUAD_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
typedef struct quadruplet quadruplet;

quadruplet* teteQuadruplets;

struct quadruplet
{
    char* operateur;
    char* operande1;
    char* operande2;
    char* resultat;
    quadruplet* suivant;
};


quadruplet* creerQuadruplet(char* operateur, char* operande1, char* operande2, char* resultat);
void insererQuadruplet(quadruplet* quad);
void creerEtInsererQuadruplet(char* operateur, char* operande1, char* operande2, char* resultat);
void afficherQuadruplet(quadruplet* quad);
void afficherListeQuadruplets();
void initialiserQuad();
int tailleListeQuadruplets();
quadruplet* recupererQuadruplet(int position);
void ecrireQuadrupletsDansFichier();
int positionQuadruplet(quadruplet* quad);
#endif
