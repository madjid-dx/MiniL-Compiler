#include "ts.h"

typedef struct listeChaines listeChaines;

struct listeChaines
{
    char* chaine;
    int type;
    listeChaines* suivant;
};


listeChaines* temporairesUtilises;
int compteurTemporaires;

bool estTemporaireUtilise(char* temporaire);
void initialiserTemporaires();
char* creerTemporaire(int type);
listeChaines* rechercherTemporaire(char* temp);
