#ifndef OPERANDES_H_INCLUDED
#define OPERANDES_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct operande operande;
typedef struct descripteurFor descripteurFor;
typedef struct descripteurConstante descripteurConstante;
typedef struct descripteurIf descripteurIf;

struct operande
{
    char* nomOuValeur;
    int type;
    operande* suivant;
};

struct descripteurFor
{
    int positionCondition;
    int positionBNZ;
    descripteurFor* suivant;
};

struct descripteurIf
{
    int positionBZ;
    descripteurIf* suivant;
};

struct descripteurConstante
{
    int type;
    char* valeur;
};

operande* pileOperandes;
descripteurFor* pileFor;
descripteurIf* pileIf;

operande* creerOperande(char* nomOuValeur, int type);
void empilerOperande(operande* op);
void creerEtEmpilerOperande(char* nom, int type);
operande* depilerOperande();
void initialiserOperandes();
void afficherOperande(operande* op);
void afficherPileOperandes();
void empilerFor();
void depilerFor();
void empilerIf();
void depilerIf();

#endif
