#include "quad.h"

quadruplet* creerQuadruplet(char* operateur, char* operande1, char* operande2, char* resultat)
{
    quadruplet* quad = malloc(sizeof(quadruplet));
    quad->operateur = strdup(operateur);
    quad->operande1 = strdup(operande1);
    quad->operande2 = strdup(operande2);
    quad->resultat = strdup(resultat);
    quad->suivant = NULL;
    return quad;
}


void insererQuadruplet(quadruplet* quad)
{
    quadruplet* courant;
    if(!teteQuadruplets)
    {
        teteQuadruplets = quad;
    }
    else
    {
        for(courant=teteQuadruplets; courant->suivant!=NULL; courant = courant->suivant);
        courant->suivant = quad;
    }
}

void creerEtInsererQuadruplet(char* operateur, char* operande1, char* operande2, char* resultat)
{
    insererQuadruplet(creerQuadruplet(operateur, operande1, operande2, resultat));
}

void afficherQuadruplet(quadruplet* quad)
{
    if(quad)
    {
        printf("%s\t", quad->operateur);
        printf("%s\t", quad->operande1);
        printf("%s\t", quad->operande2);
        printf("%s\t", quad->resultat);
    }
}

void afficherListeQuadruplets()
{
    quadruplet* tete = teteQuadruplets;
    int position = 1;
    while(tete)
    {
        printf("%d\t", position);
        afficherQuadruplet(tete);
        printf("\n");
        tete = tete->suivant;
        position++;
    }
}


void initialiserQuad()
{
    teteQuadruplets = NULL;
}


int tailleListeQuadruplets()
{
    quadruplet* courant = teteQuadruplets;
    int resultat  = 0;
    while(courant)
    {
        resultat++;
        courant = courant->suivant;
    }
    return resultat;
}


quadruplet* recupererQuadruplet(int position)
{
    quadruplet* resultat = teteQuadruplets;
    for(position--; (resultat!= NULL) && (position>0); position--)
    {
        resultat = resultat->suivant;
    }
    return resultat;
}



void ecrireQuadrupletsDansFichier()
{
    FILE* fichier = fopen("quadruplets.txt", "w+");
    quadruplet* courant= teteQuadruplets;
    if(fichier)
    {
        while(courant)
        {
            fprintf(fichier, "%s\t%s\t%s\t%s\n", courant->operateur, courant->operande1, courant->operande2, courant->resultat);
            courant = courant->suivant;
        }
        fclose(fichier);
    }
    else
    {
        printf("erreur de creation de quadruplets.txt\n");
    }
}

int positionQuadruplet(quadruplet* quad)
{
    int resultat=1;
    quadruplet* quadCourant=teteQuadruplets;
    while(quadCourant && quadCourant != quad)
    {
        resultat++;
    }
    return resultat;
}
