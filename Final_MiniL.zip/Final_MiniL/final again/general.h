#ifndef GENERAL_H_INCLUDED
#define GENERAL_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "routines.h"
#include "quad.h"
#include "operandes.h"

typedef struct etiquette etiquette;

struct etiquette
{
    char* nom;
    int numeroQuadruplet;
    etiquette* suivant;
};

extern int yylineno;
etiquette* listeEtiquettes;
int compteurEtiquettes;
FILE *erreurSyntax;
void initialiserTout();
void fin();

void genererCodeC();
char* formeCQuadruplet(quadruplet* quad);
int typeSymboleOuTemp(char* var);
char* nomType(int type);
void genererListeEtiquettes();
void ajouterEtiquette(int numeroQuadruplet);
etiquette* recupererEtiquette(int numeroQuadruplet);
void afficherListeEtiquettes();
#endif
